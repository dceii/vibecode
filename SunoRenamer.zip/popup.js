document.getElementById('startBtn').addEventListener('click', () => {
  const fileInput = document.getElementById('fileInput');
  const status = document.getElementById('status');
  if (fileInput.files.length === 0) { 
    alert("Vui lòng chọn file .txt!"); 
    return; 
  }

  const reader = new FileReader();
  reader.onload = (e) => {
    // Tách danh sách tên từ file txt
    const names = e.target.result.split('\n').map(n => n.trim()).filter(n => n !== "");
    
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: bulkRenameSuno,
        args: [names]
      });
    });
    status.innerText = "Đang chạy đổi tên & cuộn trang...";
  };
  reader.readAsText(fileInput.files[0]);
});

async function bulkRenameSuno(nameList) {
  let nameIndex = 0;
  let retryCount = 0;
  const maxRetries = 5; // Số lần thử cuộn trang nếu không tìm thấy bài mới

  console.log("Bắt đầu quy trình đổi tên hàng loạt...");

  while (nameIndex < nameList.length && retryCount < maxRetries) {
    // Quét lại danh sách link bài hát hiển thị trên màn hình hiện tại
    const songLinks = Array.from(document.querySelectorAll('a[href^="/song/"]'));
    let foundInThisBatch = false;

    for (let i = 0; i < songLinks.length; i++) {
      if (nameIndex >= nameList.length) break;

      const currentLink = songLinks[i];
      const currentName = currentLink.innerText.trim();

      // BỎ QUA nếu bài hát đã được đánh số (ví dụ: "50. Tên bài")
      if (/^\d+\./.test(currentName)) {
        continue; 
      }

      // Tìm hàng (row) và nút Edit tương ứng
      const songRow = currentLink.closest('div[role="row"]') || currentLink.parentElement.parentElement.parentElement;
      const editBtn = songRow.querySelector('button[title*="Edit title"], button[aria-label*="Edit title"]');

      if (editBtn) {
        foundInThisBatch = true;
        retryCount = 0; // Reset số lần thử lại vì vẫn tìm thấy bài để làm

        const newName = nameList[nameIndex];
        
        // Cuộn bài hát vào tầm nhìn và bấm Edit
        editBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await new Promise(r => setTimeout(r, 600));
        editBtn.click();
        
        // Đợi ô input xuất hiện
        await new Promise(r => setTimeout(r, 800));

        const input = document.querySelector('input[type="text"]');
        if (input) {
          input.focus();
          
          // Kỹ thuật ép React nhận giá trị mới (Force Update)
          const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
          nativeSetter.call(input, newName);
          input.select();
          document.execCommand('insertText', false, newName);
          
          // Kích hoạt sự kiện để nút "v" sáng lên
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
          
          await new Promise(r => setTimeout(r, 600));

          // TÌM DẤU "v" XÁC NHẬN THEO PATH BẠN CUNG CẤP
          const confirmPath = 'path[d="M9.99 16.901a1 1 0 0 1-1.414 0L4.29 12.615c-.39-.39-.385-1.029.006-1.42.39-.39 1.029-.395 1.42-.005l3.567 3.568 8.468-8.468c.39-.39 1.03-.385 1.42.006.39.39.396 1.029.005 1.42z"]';
          const checkIcon = document.querySelector(confirmPath);
          
          if (checkIcon) {
            const confirmBtn = checkIcon.closest('button');
            if (confirmBtn) confirmBtn.click();
          } else {
            // Backup: Nhấn Enter nếu không tìm thấy nút
            input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
          }

          console.log(`Đã đổi: ${newName}`);
          nameIndex++;
          // Đợi Suno lưu xong trước khi sang bài tiếp theo
          await new Promise(r => setTimeout(r, 1200));
        }
      }
    }

    // Nếu đã quét hết bài trên màn hình mà chưa dùng hết danh sách tên trong file
    // Thực hiện cuộn xuống để Suno nạp thêm bài mới (Lazy Load)
    if (!foundInThisBatch && nameIndex < nameList.length) {
      window.scrollBy(0, 1000); // Cuộn xuống 1000 pixel
      retryCount++;
      console.log(`Đang cuộn tìm bài mới... (Lần thử ${retryCount})`);
      await new Promise(r => setTimeout(r, 5000)); // Đợi trang web load dữ liệu mới
    }
  }

  alert(`Hoàn thành! Đã đổi tên thành công ${nameIndex} bài hát.`);
}